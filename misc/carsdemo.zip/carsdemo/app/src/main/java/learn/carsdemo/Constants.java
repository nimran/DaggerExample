package learn.carsdemo;



public class Constants {

    public static final String SERVICE_URL = "https://raw.githubusercontent.com/nimran/DaggerExample/master/misc/demo.json";
}
