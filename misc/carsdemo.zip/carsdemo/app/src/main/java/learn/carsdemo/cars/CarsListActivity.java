package learn.carsdemo.cars;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import learn.carsdemo.R;
import learn.carsdemo.model.Cars;
import learn.carsdemo.util.AppUtils;

public class CarsListActivity extends AppCompatActivity {

    public static final String SELECTED_YEAR = "selected_year";
    public static final String SELECTED_RATING = "selected_rating";


    private CarsListAdapter adapter;
    private RecyclerView recyclerView;
    private Toolbar toolbar;
    private TextView errorMessageView;
    private List<Cars> carsList = new ArrayList<Cars>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cars_list);
        getData();
        bindViews();
    }

    private void getData() {
        if(AppUtils.responseMap.get(AppUtils.CARS_RESPONSE) != null) {
            carsList = (List<Cars>) AppUtils.responseMap.get(AppUtils.CARS_RESPONSE);
        }
    }

    private void bindViews() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        errorMessageView = findViewById(R.id.error);
        recyclerView = findViewById(R.id.cars_list);
        adapter = new CarsListAdapter(carsList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        setTitle("Filtered Results");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        getFilters();
    }

    private void getFilters() {
        Intent intent = getIntent();
        if(intent != null && intent.getExtras() != null) {
            String selectedYear = intent.getExtras().getString(SELECTED_YEAR);
            String selectedRating = intent.getExtras().getString(SELECTED_RATING);

            parseResults(selectedYear,selectedRating);
        }
    }

    private void parseResults(String selectedYear, String selectedRating) {

        List<Cars> filteredList = new ArrayList<>();
        for(Cars cars : carsList) {
            if(cars.getYear().equalsIgnoreCase(selectedYear) && String.valueOf(cars.getRating()).equalsIgnoreCase(selectedRating)) {
                filteredList.add(cars);
            }
        }

        if(filteredList.size() > 0) {
            Toast.makeText(getApplicationContext(),"Found "+filteredList.size() +" match",Toast.LENGTH_LONG).show();
            adapter.setItems(filteredList);
            adapter.notifyDataSetChanged();
            errorMessageView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            errorMessageView.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
    }
}
