package learn.carsdemo.home;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatSpinner;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import learn.carsdemo.R;
import learn.carsdemo.cars.CarsListActivity;
import learn.carsdemo.model.Cars;

public class HomeActivity extends AppCompatActivity implements HomeContract.View{

    private AppCompatSpinner yearChooser;
    private AppCompatSpinner ratingChooser;
    private Button searchBtn;
    private ProgressDialog pDialog;

    HomeContract.Presenter presenter;

    private List<Cars> carsList = new ArrayList<Cars>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        presenter = new HomePresenter(this);
        bindViews();
        loadData();
    }

    private void bindViews() {
        yearChooser = (AppCompatSpinner) findViewById(R.id.year_chooser);
        ratingChooser = (AppCompatSpinner) findViewById(R.id.rating_chooser);
        searchBtn = (Button) findViewById(R.id.search_button);

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchCars();
            }
        });
    }

    private void loadData() {
        presenter.onCreate();

    }


    /**
     * Set up the spinner based on the items fetched from the response
     */
    public void populateUI(List<Cars> carsList) {
        this.carsList = carsList;
        if (carsList.size() > 0) {

            final List<String> yearsList = new ArrayList<String>();
            final List<Integer> ratingList = new ArrayList<Integer>();

            for (Cars cars : carsList) {
                if(!yearsList.contains(cars.getYear())) {
                    yearsList.add(cars.getYear());
                }
                if(!ratingList.contains(cars.getRating())) {
                    ratingList.add(cars.getRating());
                }
            }

            //sort
            Collections.sort(yearsList, new Comparator<String>(){
                public int compare(String obj1, String obj2) {
                    return obj1.compareToIgnoreCase(obj2);
                }
            });
            Collections.sort(ratingList, new Comparator<Integer>(){
                public int compare(Integer obj1, Integer obj2) {
                    return obj1.compareTo(obj2);
                }
            });

            //end of sort
            ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, yearsList);
            yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            yearChooser.setAdapter(yearAdapter);

            ArrayAdapter<Integer> ratingAdapter = new ArrayAdapter<Integer>(this,
                    android.R.layout.simple_list_item_1, ratingList);
            ratingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            ratingChooser.setAdapter(ratingAdapter);
        }
    }

    @Override public void showLoading() {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);
        pDialog.show();
    }

    @Override public void hideLoading() {
        if (pDialog != null && pDialog.isShowing()) {
            pDialog.dismiss();
            pDialog = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        hideLoading();
    }


    private void searchCars() {
        Intent intent = new Intent(HomeActivity.this, CarsListActivity.class);
        intent.putExtra(CarsListActivity.SELECTED_RATING,ratingChooser.getSelectedItem().toString());
        intent.putExtra(CarsListActivity.SELECTED_YEAR,yearChooser.getSelectedItem().toString());
        startActivity(intent);
    }

}
