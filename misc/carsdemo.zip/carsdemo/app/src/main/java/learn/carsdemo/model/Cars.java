package learn.carsdemo.model;


import android.os.Parcel;
import android.os.Parcelable;

public class Cars implements Parcelable {


    private int id;
    private String name;
    private String imageUrl;
    private String year;
    private int rating;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.name);
        dest.writeString(this.imageUrl);
        dest.writeString(this.year);
        dest.writeInt(this.rating);
    }

    public Cars() {
    }

    protected Cars(Parcel in) {
        this.id = in.readInt();
        this.name = in.readString();
        this.imageUrl = in.readString();
        this.year = in.readString();
        this.rating = in.readInt();
    }

    public static final Parcelable.Creator<Cars> CREATOR = new Parcelable.Creator<Cars>() {
        @Override
        public Cars createFromParcel(Parcel source) {
            return new Cars(source);
        }

        @Override
        public Cars[] newArray(int size) {
            return new Cars[size];
        }
    };
}
