package learn.carsdemo.util;

import java.util.HashMap;

public class AppUtils {

    public static String CARS_RESPONSE = "cars_response";

    public static HashMap<String,Object> responseMap  = new HashMap<>();
}
