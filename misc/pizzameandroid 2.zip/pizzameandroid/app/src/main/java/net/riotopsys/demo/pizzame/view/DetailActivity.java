package net.riotopsys.demo.pizzame.view;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;

import net.riotopsys.demo.pizzame.databinding.DetailActivityBinding;
import net.riotopsys.demo.pizzame.inject.InjectedApplication;
import net.riotopsys.demo.pizzame.network.model.QueryResult;
import net.riotopsys.demo.pizzame.view_model.DetailViewModel;
import net.riotopsys.demo.pizzame.view_model.ListItemViewModel;

import javax.inject.Inject;


/**
 * Created by adam.fitzgerald on 8/18/16.
 */
public class DetailActivity extends AppCompatActivity {
    public static final String RECORD = DetailActivity.class.getCanonicalName() + "+record";
    @Inject
    protected ListItemViewModel vmLi;
    @Inject
    protected DetailViewModel dvm;
    private QueryResult.Result data;
    private DetailActivityBinding binding;

    public DetailActivity() {
        InjectedApplication.getComponent().inject(this);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DetailActivityBinding.inflate(LayoutInflater.from(this));
        setContentView(binding.getRoot());

        binding.setVmLI(vmLi);
        binding.setDvm(dvm);

        data = (QueryResult.Result) getIntent().getSerializableExtra(RECORD);

        vmLi.setData(data);
        dvm.setData(data);
    }
}
