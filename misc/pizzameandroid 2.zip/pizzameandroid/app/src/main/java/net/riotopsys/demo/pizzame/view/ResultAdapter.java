package net.riotopsys.demo.pizzame.view;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import net.riotopsys.demo.pizzame.databinding.ListItemBinding;
import net.riotopsys.demo.pizzame.inject.InjectedApplication;
import net.riotopsys.demo.pizzame.network.model.QueryResult;
import net.riotopsys.demo.pizzame.view_model.ListItemViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by adam.fitzgerald on 8/16/16.
 */
public class ResultAdapter extends RecyclerView.Adapter {
    private ArrayList<QueryResult.Result> list = new ArrayList<>();

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(ListItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ViewHolder vh = (ViewHolder) holder;
        setMockedList();
        vh.binding.getVm().setData(list.get(position));
    }


    private void setMockedList() {
        QueryResult.Result q = new QueryResult.Result();
        q.address = "1530 Overland Park ln";
        q.title = "Tony's Pizza";
        q.city = "Charalotte";
        q.state = "NC";
        q.phone = "(979) 1020690";

        list.add(q);
        list.add(q);

        list.add(q);
        list.add(q);
    }

    @Override
    public int getItemCount() {
        return 4;
    }

    public void update(List<QueryResult.Result> list) {
        this.list.clear();
        this.list.addAll(list);
        notifyDataSetChanged();
    }

    private static final class ViewHolder extends RecyclerView.ViewHolder {

        private final ListItemBinding binding;

        private ViewHolder(ListItemBinding binding) {
            super(binding.getRoot());

            this.binding = binding;
            ListItemViewModel vm = InjectedApplication.getComponent().create();
            binding.setVm(vm);
        }
    }

}
