package net.riotopsys.demo.pizzame.view_model;

import android.content.Intent;
import android.databinding.BaseObservable;
import android.net.Uri;
import android.view.View;

import net.riotopsys.demo.pizzame.network.model.QueryResult;

import java.util.Locale;

import javax.inject.Inject;

/**
 * Created by adam.fitzgerald on 8/18/16.
 */
public class DetailViewModel extends BaseObservable {

    private QueryResult.Result data = null;

    @Inject
    public DetailViewModel() {
    }


    public void setData(QueryResult.Result data) {
        this.data = data;
        notifyChange();
    }

    public void onPhoneClick(View view) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + data.phone));
        view.getContext().startActivity(intent);
    }

    public void onMapClick(View view) {
        Uri gmmIntentUri = Uri.parse(String.format(Locale.getDefault(), "geo:%.4f,%.4f?q=pizza", data.latitude, data.longitude));
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        view.getContext().startActivity(mapIntent);
    }

    public void onWebClick(View view) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(data.businessUrl.toString()));
        view.getContext().startActivity(i);
    }
}
