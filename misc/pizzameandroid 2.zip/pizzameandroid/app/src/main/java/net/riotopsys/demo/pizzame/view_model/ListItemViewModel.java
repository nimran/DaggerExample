package net.riotopsys.demo.pizzame.view_model;

import android.content.Intent;
import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.view.View;

import net.riotopsys.demo.pizzame.network.model.QueryResult;
import net.riotopsys.demo.pizzame.view.DetailActivity;

import java.util.Locale;

import javax.inject.Inject;

/**
 * Created by adam.fitzgerald on 8/17/16.
 */
public class ListItemViewModel extends BaseObservable implements View.OnClickListener {


    private QueryResult.Result data;

    @Inject
    ListItemViewModel() {

    }

    @Bindable
    public String getTitle() {
        return data.title;
    }

    @Bindable
    public String getAddress() {
        return data.address;
    }

    @Bindable
    public String getCity() {
        return data.city;
    }

    @Bindable
    public String getState() {
        return data.state;
    }

    @Bindable
    public String getDistance() {
        return String.format(Locale.getDefault(), "%.1f mi", data.calc.distance * 0.00062137);
    }

    @Bindable
    public String getPhone() {
        return data.phone;
    }

    public void setData(QueryResult.Result data) {


        this.data = data;
        this.notifyChange();
    }

    @Override
    public void onClick(View view) {
        view.getContext().startActivity(new Intent(view.getContext(), DetailActivity.class).putExtra(DetailActivity.RECORD, data));
    }
}
